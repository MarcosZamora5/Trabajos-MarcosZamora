/*
    Mini programa que permite escribir tareas, eliminar, completar y que cumple con tres librerias
    como la libreria awt.event, swing y date las cuales nos ayudan a la elaboracion del pequeño programa.
    Alumnos:
    Diaz Sanchez Pablo Gabriel
    Zamora Reyes Marcos Francisco 
    Materia: Topicos avanzados de programacion 
*/
package App;
import javax.swing.*; /* Biblioteca para la creacion de interfaces graficas en Java
simplifica la creacion de ventanas, botones, cuadros de texto y otros componentes graficos
asi tambien se integra muy bien con el modelo de eventos en Java y su facilidad de uso 
*/
import java.awt.*; /* Proporciona herramientas para elaborar diseño y componentes graficos y
facilita la personalizacion de la aplicacion y proporciona multiples gestores de diseño
*/
import java.awt.event.*; /* Maneja eventos dentro de la interfaz grafica
Permite que el usuario pueda interactuar con el programa y es fundamental para la creacion de interfaces 
donde el usuario tenfa que interactuar haciendolas dinamicas
*/
import java.text.SimpleDateFormat; /* Permite la elaboracion de fechas
simplifica la conversion de fechas a cadenas de texto y mejora la legibilidad y manipulacion
de fechas en la aplicacion
*/
import java.util.ArrayList; /* Libreria que nos permite usar listas dinamicas
mejora la gestion de colecciones y destaca en su eficiencia en operaciones de acceso y modificacion
*/
import java.util.Date; /*Manejo de fechas
permite presentar echas e igual las convierte a cadenas legibles
*/

public class main {

    // Creamos nuestra clase estatica llamada Tarea con sus atributos
    static class Tarea {
        String nombre;
        Date fecha;
        String hora;
        boolean completada;
        
        // Generamos un constructos para nuestros atributos
        Tarea(String nombre, Date fecha, String hora) {
            this.nombre = nombre;
            this.fecha = fecha;
            this.hora = hora;
            this.completada = false;
        }
        
        // Metodo sobre escrito que nos pemite mostrar la tarea como una cadena de texto
        @Override
        public String toString() {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
            String estado = completada ? "(Completada)" : "(Pendiente)";
            return estado + " Tarea: " + nombre + ", Fecha de vencimiento: " + dateFormat.format(fecha) + ", Hora de vencimiento: " + hora;
        }
    }
    
    
    private static ArrayList<Tarea> tareaLista = new ArrayList<>(); // Lista para almacenar tareas
    private static JTextArea tareaDisplayArea; // Area de texto para mostrar tareas
    private static JTextField tareaNombreField, tareaFechaField, tareaHoraField; // Campos de entrada de datos
    private static JComboBox<String> tareaComboBox; // ComboBox para selccionar tareas

    public static void main(String[] args) {
        JFrame frame = new JFrame("Gestor de tareas"); //Creamos la ventana principañ
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Panel de entrada de datos
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(4, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Creamos nuestras etiquetas y campos de entrada
        JLabel tareaNombreLabel = new JLabel("Nombre de la tarea:");
        tareaNombreField = new JTextField();
        JLabel tareaFechaLabel = new JLabel("Fecha de vencimiento (dd-MM-yyyy):");
        tareaFechaField = new JTextField();
        JLabel tareaHoraLabel = new JLabel("Hora de vencimiento (00:00):");
        tareaHoraField = new JTextField();

        // Creamos nuestros botones para agregar tareas
        JButton addButton = new JButton("Agregar tarea");
        addButton.setBackground(new Color(0, 153, 76));
        addButton.setForeground(Color.WHITE);
        addButton.setFocusPainted(false);
        addButton.addActionListener(e -> addTask());

        // Agregamos componentes al panel
        inputPanel.add(tareaNombreLabel);
        inputPanel.add(tareaNombreField);
        inputPanel.add(tareaFechaLabel);
        inputPanel.add(tareaFechaField);
        inputPanel.add(tareaHoraLabel);
        inputPanel.add(tareaHoraField);
        inputPanel.add(addButton);

        // Visualizamos nuestras tareas
        tareaDisplayArea = new JTextArea();
        tareaDisplayArea.setEditable(false);
        tareaDisplayArea.setFont(new Font("Arial", Font.PLAIN, 14));
        tareaDisplayArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JScrollPane scrollPane = new JScrollPane(tareaDisplayArea);

        // Area de botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton viewButton = new JButton("Ver Tareas");
        viewButton.setBackground(new Color(0, 102, 204));
        viewButton.setForeground(Color.WHITE);
        viewButton.setFocusPainted(false);
        viewButton.addActionListener(e -> displayTasks());

        tareaComboBox = new JComboBox<>();
        JButton deleteButton = new JButton("Eliminar Tarea");
        deleteButton.setBackground(new Color(204, 0, 0));
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setFocusPainted(false);
        deleteButton.addActionListener(e -> deleteTask());

        JButton completeButton = new JButton("Marcar como Completada");
        completeButton.setBackground(new Color(255, 153, 0));
        completeButton.setForeground(Color.WHITE);
        completeButton.setFocusPainted(false);
        completeButton.addActionListener(e -> completeTask());

        // Agregamos botones al panel
        buttonPanel.add(viewButton);
        buttonPanel.add(tareaComboBox);
        buttonPanel.add(deleteButton);
        buttonPanel.add(completeButton);
        
        // Agregamos paneles al frame
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }
    
    // Metodo para agregar una tarea a la lista
    private static void addTask() {
        String nombre = tareaNombreField.getText().trim();
        String fechaString = tareaFechaField.getText().trim();
        String hora = tareaHoraField.getText().trim();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El nombre de la tarea no puede estar vacío.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            Date fecha = dateFormat.parse(fechaString);
            tareaLista.add(new Tarea(nombre, fecha, hora));
            tareaComboBox.addItem(nombre);
            JOptionPane.showMessageDialog(null, "Tarea agregada exitosamente.");
            tareaNombreField.setText("");
            tareaFechaField.setText("");
            tareaHoraField.setText("");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: Formato de fecha inválido.");
        }
    }
    
    // Metodo para mostrar las tareas en el area de texto
    private static void displayTasks() {
        if (tareaLista.isEmpty()) {
            tareaDisplayArea.setText("No hay tareas para mostrar.");
        } else {
            StringBuilder tareasTexto = new StringBuilder();
            for (Tarea tarea : tareaLista) {
                tareasTexto.append(tarea).append("\n");
            }
            tareaDisplayArea.setText(tareasTexto.toString());
        }
    }

    // Metodo para eliminar una tarea seleccionada
    private static void deleteTask() {
        int index = tareaComboBox.getSelectedIndex();
        if (index >= 0) {
            tareaLista.remove(index);
            tareaComboBox.removeItemAt(index);
            JOptionPane.showMessageDialog(null, "Tarea eliminada exitosamente.");
            displayTasks();
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una tarea para eliminar.");
        }
    }

    // Metodo para marcar una tarea como completada
    private static void completeTask() {
        int index = tareaComboBox.getSelectedIndex();
        if (index >= 0) {
            tareaLista.get(index).completada = true;
            JOptionPane.showMessageDialog(null, "Tarea marcada como completada.");
            displayTasks();
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una tarea para marcar como completada.");
        }
    }
}
